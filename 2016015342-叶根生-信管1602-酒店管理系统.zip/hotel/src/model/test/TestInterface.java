package model.test;


abstract public class TestInterface {
	public abstract void method();
}
