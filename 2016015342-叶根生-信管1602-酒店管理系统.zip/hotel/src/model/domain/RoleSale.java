package model.domain;

public class RoleSale {
	private String guestRole;
	private float dismiss;

	public void setguestRole(String guestRole) {
		this.guestRole = guestRole;
	}

	public void setdismiss(float dismiss) {
		this.dismiss = dismiss;
	}

	public String getguestRole() {
		return guestRole;
	}

	public float getdismiss() {
		return dismiss;
	}
}
