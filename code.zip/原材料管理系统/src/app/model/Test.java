package app.model;

public class Test {
	public static void main(String[] args) {
		System.out.println(Database.use("INSERT INTO MaterialManagement.user VALUES ('wangming' , '2016015338')", null));
	}
}
